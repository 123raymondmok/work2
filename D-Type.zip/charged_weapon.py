import pygame



class chargedPlayerWeapon(Weapon):
  def __init__(self, x,y)















