import pygame



class EnemyWeapon(pygame.sprite.Sprite):
  counter=0                         
  self.x0,self.y0=self.rect.x,self.rect.y
  x1,y1=target_x-x,target_y-y
  
  def __init__(self, x,y,sound):
  def draw(self,surface):
  def move(self):
    self.rect.x=self.x0+self+x1*counter
    self.rect.y=self.y0+self+y1*counter
    self.counter+=2
  if self.rect.x < self.rect.y:
    self.










